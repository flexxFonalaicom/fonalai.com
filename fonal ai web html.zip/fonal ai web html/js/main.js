/* ========================================================
   Fonal AI — Main JavaScript
   Mobile nav drawer, cookie consent, toast notifications
   ======================================================== */

(function () {
  "use strict";

  /* =====================
     MOBILE MENU (Nav Drawer)
     ===================== */
  const hamburgerBtns = document.querySelectorAll(".dock-hamburger, .dock-hamburger-desktop");
  const mobileMenu = document.querySelector(".mobile-menu");

  function openMobileMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.add("is-open");
    document.body.style.overflow = "hidden";
    hamburgerBtns.forEach(function (btn) { btn.classList.add("is-open"); });
  }

  function closeMobileMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.remove("is-open");
    document.body.style.overflow = "";
    hamburgerBtns.forEach(function (btn) { btn.classList.remove("is-open"); });
  }

  hamburgerBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (mobileMenu && mobileMenu.classList.contains("is-open")) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    });
  });

  if (mobileMenu) {
    var closeBtn = mobileMenu.querySelector(".mobile-menu-close");
    if (closeBtn) closeBtn.addEventListener("click", closeMobileMenu);

    mobileMenu.addEventListener("click", function (e) {
      if (e.target === mobileMenu) closeMobileMenu();
    });
  }

  /* =====================
     COOKIE CONSENT
     Once per user — remembered via a signed, tamper-evident token.
     Refreshes / page changes never re-show it for that user.
     Forging or half-deleting the stored token is detected and reset.
     ===================== */
  var COOKIE_KEY = "fonal_cc_2026";
  var COOKIE_KEY2 = "fonal_cc_sess";
  var COOKIE_MARKER = "fa1_cc0re";
  var COOKIE_SALT = "f0nAl#cc#2026";
  var COOKIE_EXPIRY_DAYS = 180;

  function ccChecksum(id, exp) {
    var str = id + "|" + COOKIE_MARKER + "|" + exp + "|" + COOKIE_SALT;
    var h = 7;
    for (var i = 0; i < str.length; i++) {
      h = (h * 31 + str.charCodeAt(i)) % 1000003;
    }
    return h.toString(36) + "-" + (h % 997);
  }

  function makeConsentToken() {
    var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var id = "";
    for (var i = 0; i < 32; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    var exp = Date.now() + COOKIE_EXPIRY_DAYS * 24 * 3600 * 1000;
    return btoa(JSON.stringify({ id: id, m: COOKIE_MARKER, exp: exp, s: ccChecksum(id, exp) }));
  }

  function consentTokenValid(token) {
    if (typeof token !== "string" || token.length < 24) return false;
    try {
      var o = JSON.parse(atob(token));
      if (!o || o.m !== COOKIE_MARKER) return false;
      if (typeof o.id !== "string" || o.id.length < 16) return false;
      if (typeof o.exp !== "number" || Date.now() > o.exp) return false;
      if (o.s !== ccChecksum(o.id, o.exp)) return false;
      return true;
    } catch (err) {
      return false;
    }
  }

  function grantConsent() {
    var token = makeConsentToken();
    try { localStorage.setItem(COOKIE_KEY, token); } catch (err) {}
    try { sessionStorage.setItem(COOKIE_KEY2, token); } catch (err) {}
  }

  function hasConsent() {
    var a = null, b = null;
    try { a = localStorage.getItem(COOKIE_KEY); } catch (err) {}
    try { b = sessionStorage.getItem(COOKIE_KEY2); } catch (err) {}

    var validA = consentTokenValid(a);
    var validB = consentTokenValid(b);

    if (validA && validB) return a === b;
    if (validA) { try { sessionStorage.setItem(COOKIE_KEY2, a); } catch (err) {} return true; }
    if (validB) { try { localStorage.setItem(COOKIE_KEY, b); } catch (err) {} return true; }

    // Half-broken or forged leftovers — wipe them so the user re-consents cleanly.
    if (a || b) {
      try { localStorage.removeItem(COOKIE_KEY); } catch (err) {}
      try { sessionStorage.removeItem(COOKIE_KEY2); } catch (err) {}
    }
    return false;
  }

  function showCookieBanner() {
    if (hasConsent()) return;
    if (document.getElementById("cookie-overlay")) return;

    var overlay = document.createElement("div");
    overlay.id = "cookie-overlay";
    overlay.className = "cookie-overlay";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", "Cookie consent");

    overlay.innerHTML =
      '<div class="cookie-card glass">' +
        '<div class="cookie-icon">' +
          '<svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 -960 960 960" width="48px" fill="#DF9D9B"><path d="M480.27-80q-82.74 0-155.5-31.5Q252-143 197.5-197.5t-86-127.5Q80-398 80-480q0-83 31.5-155.5T197-763q54-55 126-86.5T475.56-881q19.44 0 38.44 1.5 19 1.5 38 5.5-6 40 6.5 78.5t39 68q26.5 29.5 66.5 45t89 9.5q-7 63 22 109t104 53q1 9 1 18v17q0 81.38-31.5 153.34Q817-250.71 763-196.62t-127 85.36Q563-80 480.27-80Zm-60.15-478Q446-558 464-576.12q18-18.12 18-44T463.88-664q-18.12-18-44-18T376-663.88q-18 18.12-18 44T376.12-576q18.12 18 44 18Zm-80 200Q366-358 384-376.12q18-18.12 18-44T383.88-464q-18.12-18-44-18T296-463.88q-18 18.12-18 44T296.12-376q18.12 18 44 18ZM600-320q17 0 28.5-11.5T640-360q0-17-11.5-28.5T600-400q-17 0-28.5 11.5T560-360q0 17 11.5 28.5T600-320ZM480-140q142 0 236-93.5T821-464q-54-20-87.5-59.5T692-614q-81-11-136.5-70T492-821q-74-3-138.5 24t-112 74Q194-676 167-612.5T140-480q0 142 99 241t241 99Zm1-345Z"/></svg>' +
        '</div>' +
        '<h2>We use cookies</h2>' +
        '<p>Hi, thanks for visiting Fonal AI. This is a prototype of what the future looks like — built to make sure you are 100% safe. Please use this site to acquire knowledge.</p>' +
        '<p style="margin-bottom: 1.5rem;">If you want to buy or collaborate with Fonal AI, you can email us at <a href="mailto:rishicrypto1818@gmail.com" style="color: var(--primary); font-weight: 500;">rishicrypto1818@gmail.com</a>.</p>' +
        '<button id="cookie-accept-btn" class="btn btn-primary btn-lg btn-full">Accept</button>' +
      '</div>';

    document.body.appendChild(overlay);
    document.body.style.overflow = "hidden";

    setTimeout(function () {
      overlay.classList.add("is-visible");
    }, 50);

    document.getElementById("cookie-accept-btn").addEventListener("click", function () {
      grantConsent();
      overlay.classList.remove("is-visible");
      document.body.style.overflow = "";
      setTimeout(function () {
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      }, 350);
    });
  }

  // New visitor: wait 4 seconds, then ask for consent — once only.
  setTimeout(showCookieBanner, 4000);

  /* =====================
     TOAST NOTIFICATIONS
     ===================== */
  var toastStack = null;

  function ensureToastStack() {
    if (!toastStack || !document.body.contains(toastStack)) {
      toastStack = document.createElement("div");
      toastStack.className = "toast-stack";
      document.body.appendChild(toastStack);
    }
    return toastStack;
  }

  function showToast(message, duration) {
    var wrap = ensureToastStack();
    var toast = document.createElement("div");
    toast.className = "toast";
    toast.setAttribute("role", "status");
    toast.innerHTML =
      '<span class="toast-icon">' +
        '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>' +
      '</span>' +
      '<div class="toast-body">' + message + '</div>' +
      '<button type="button" class="toast-close" aria-label="Dismiss"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>';
    wrap.appendChild(toast);

    requestAnimationFrame(function () { toast.classList.add("is-visible"); });

    function destroy() {
      toast.classList.remove("is-visible");
      setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }

    var closeBtn = toast.querySelector(".toast-close");
    if (closeBtn) closeBtn.addEventListener("click", destroy);
    if (duration !== 0) setTimeout(destroy, duration || 5000);
  }

  function notifyUnavailable() {
    showToast("This service is not available in your region. Please continue with email.");
  }

  window.FonalUI = window.FonalUI || {};
  window.FonalUI.toast = showToast;
  window.FonalUI.notAvailable = notifyUnavailable;

  /* =====================
     GENERIC: Close mobile menus on resize
     ===================== */
  window.addEventListener("resize", function () {
    if (window.innerWidth > 768) {
      closeMobileMenu();
    }
  });

})();