# FULL DESIGN & BUILD PROMPT — Fonal AI Website (recreate in pure HTML + CSS + vanilla JS)

**Deliverable:** A complete multi-page marketing website + dashboard, built **ONLY in pure HTML, CSS and vanilla JavaScript** — no frameworks, no build tools, no React, no component/UI libraries on CDN. Just `.html`, `.css`, `.js` files. It must run by simply opening `index.html` in a browser or uploading the folder to any static host (file:// or www).

Reproduce the entire look, feel, color system, typography, glassmorphism, layout structure, animations and micro-interactions of the original Fonal AI website as faithfully as possible.

---

## 1. BRAND & CONTEXT
- Product: **Fonal AI** — an AI agency that helps businesses automate daily workflows, deliver clear end-of-day data reports, do business analysis, and support scaling.
- Home headline: **"A new level of freedom for your business"** (the word "business" is highlighted in the brand primary color).
- Home subheadline: **"Fonal AI change the way of doing business"**.
- Badge above the headline: **"Join the AI workflow"**.
- Setup the SEO meta title "Fonal AI — Implement AI in Your Business" and matching og/description in each `<head>`.

---

## 2. DESIGN TOKENS & COLOR SYSTEM (CRITICAL — use these EXACT oklch values)
Define in `:root`:

| Token | Value | Purpose |
|---|---|---|
| `--radius` | `0.75rem` | base radius; radius scales derive from it (sm=base-4, md=base-2, lg=base, xl=base+4, 2xl=base+8, 3xl=base+12, 4xl=base+16 px) |
| `--background` | `oklch(0.985 0.008 235)` | near-white pale blue (default light bg) |
| `--foreground` | `oklch(0.21 0.045 255)` | deep ink/navy (main text) |
| `--card` | `oklch(1 0 0)` | white surface |
| `--card-foreground` | `oklch(0.21 0.045 255)` | |
| `--popover` | `oklch(1 0 0)` | |
| `--popover-foreground` | `oklch(0.21 0.045 255)` | |
| `--primary` | `oklch(0.52 0.17 250)` | electric blue-violet (buttons, links, accent, active) |
| `--primary-foreground` | `oklch(0.985 0.005 240)` | near-white on primary |
| `--secondary` | `oklch(0.94 0.02 240)` | soft gray-blue |
| `--secondary-foreground` | `oklch(0.3 0.06 255)` | |
| `--muted` | `oklch(0.94 0.02 240)` | */br> soft bg |
| `--muted-foreground` | `oklch(0.5 0.04 255)` | lowered-contrast secondary text |
| `--accent` | `oklch(0.92 0.035 235)` | hover/fill tint |
| `--accent-foreground` | `oklch(0.3 0.08 255)` | |
| `--destructive` | `oklch(0.577 0.245 27.325)` | red error |
| `--destructive-foreground` | `oklch(0.985 0.005 240)` | |
| `--border` | `oklch(0.9 0.02 245)` | hairline |
| `--input` | `oklch(0.9 0.02 245)` | input border |
| `--ring` | `oklch(0.6 0.14 250)` | focus ring |
| `--sky-deep` | `oklch(0.45 0.15 255)` | deep sky for gradient orbs |
| `--sky-soft` | `oklch(0.82 0.07 230)` | soft ice blue for glow blobs |
| `--ice` | `oklch(0.96 0.02 230)` | very light icy blue |

Fonts: `--font-display: "Space Grotesk", ui-sans-serif, system-ui, sans-serif;` and `--font-sans: "DM Sans", ui-sans-serif, system-ui, sans-serif;`

---

## 3. TYPOGRAPHY
- **Display font:** Space Grotesk (500/600/700) — headlines, brand wordmark, section titles, big stat numbers.
- **Body font:** DM Sans (400/500/600/700) — body, nav, buttons, labels, inputs.
- Load both via two `<link rel="preconnect">` (fonts.googleapis.com + fonts.gstatic.com, gstatic with `crossorigin="anonymous"`) and one Google Fonts stylesheet link in every `<head>`.
- Set `h1/h2/h3/h4` to use the display font; `body` uses the sans font with `--background`/`--foreground`.
- **Headline scale:** mobile `text-5xl` → desktop `text-6xl`/`text-7xl`, `font-bold`, tight line-height ≈1.05, `letter-spacing: -0.03em`, centered, `text-wrap: balance`, white on gradient.
- **Kicker/eyebrow labels:** small, uppercase, semibold, wide letter-spacing, in `--primary` (e.g. "Welcome back").
- **Stat numbers:** display font, huge, bold, in `--primary`.

---

## 4. SURFACE EFFECTS (Glassmorphism — the signature look)
Define these utility classes EXACTLY:

**.hero-gradient** (the page background):
```
background:
  radial-gradient(120% 90% at 85% 10%, oklch(0.75 0.10 230) 0%, transparent 55%),
  radial-gradient(100% 80% at 10% 90%, oklch(0.70 0.12 250) 0%, transparent 50%),
  linear-gradient(160deg, oklch(0.88 0.05 235) 0%, oklch(0.66 0.12 245) 55%, oklch(0.50 0.15 252) 100%);
```

**.glass** (frosted card on light bg):
```
background: oklch(1 0 0 / 0.55);
backdrop-filter: blur(18px);
border: 1px solid oklch(1 0 0 / 0.65);
```

**.glass-deep** (translucent panel over the gradient, text white):
```
background: oklch(1 0 0 / 0.12);
backdrop-filter: blur(20px);
border: 1px solid oklch(1 0 0 / 0.30);
```

**.dock-blur** (floating header pill AND the dashboard sidebar):
```
background: oklch(1 0 0 / 0.60);
backdrop-filter: blur(24px) saturate(140%);
border: 1px solid oklch(1 0 0 / 0.70);
box-shadow: 0 12px 40px -12px oklch(0.45 0.12 250 / 0.18);
```

**Ambient gradient orbs:** absolutely-positioned large circles (`width/height: 24rem`, `border-radius: 50%`), one `--sky-soft` at top-right and one `--sky-deep` (at 40% alpha) at bottom-left, each `opacity: 0.55` and `filter: blur(90px)`, inside a page container with `overflow: hidden`.

**Radius scale:** cards `rounded-[2rem]` (2rem) and `rounded-3xl` (base+12); pills `rounded-full`; standard cards `rounded-2xl` (base+8).

---

## 5. ANIMATIONS & MOTION (reproduce EACH)
- **dock fade in** (the floating pill header / bottom-left dock):
  ```
  @keyframes { 
    0%   { opacity:0; filter:blur(12px); transform: translateY(-14px) scale(0.96); }
    100% { opacity:1; filter:blur(0);    transform: translateY(0)     scale(1); } }
  ```
  0.85s, easing `cubic-bezier(0.16, 1, 0.3, 1)`, `forwards`.
- **scale in** — cards/panels scale+fade up from 0.95 on load.
- **fade in** — hero title & content fade up into place on load.
- **Button hover micro-interactions:**
  - Primary buttons: `scale 1.02` hover, `scale 0.95` active, large soft brand shadow `0 25px 50px -12px oklch(0.45 0.12 250 / 0.28)`.
  - Ghost/outline buttons: bg → `--accent` on hover; `scale 0.95` active.
  - Icon buttons: hover → soft accent bg; `scale 0.95` active.
- **Wordmark "FonalAI":** on hover the whole wordmark letter-spacing widens (→ `tracking-wide`), and "AI" (in `--primary`) swaps to `--foreground` while "Fonal" tints `--primary`. (group-hover on the dock.)
- **Hamburger (3 × 2px lines):** on hover middle line turns brand; top/bottom lines shrink width and turn brand. (group-hover/menu.)
- **Nav links:** `transition-colors` 300ms; hover brightens.
- All transitions 200–500ms, `ease-out` / `ease-in-out`.
- **Dashboard nav items:** active = soft `--primary`-tinted background + `--primary` icon + text; inactive = muted ink, brighten to full on hover.

---

## 6. HEADER / NAV (all pages EXCEPT the dashboard)
- A **fixed floating pill dock** at the **top center**: horizontally centered, `max-width 5xl`-ish, `border-radius: 9999px`, uses `.dock-blur`, padding ≈10px, entrance `dock fade in`. On hover it lifts and casts the deeper brand-tinted shadow (`0 20px 50px -12px oklch(0.45 0.12 250 / 0.22)`).
- **Left:** hamburger icon + **"Fonal AI"** wordmark (Space Grotesk bold; "AI" in `--primary`).
- **Center (desktop):** nav links — Home, About, Services, Connect. The current page shows as a filled `--primary` pill. Others subtle with hover.
- **Right:** **"Connect"** (filled primary pill + arrow icon) and **"Log in"** (outline glass pill + log-in icon). On small screens they collapse into the mobile menu.
- **Mobile:** hamburger toggles a drawer / menu; hidden by default, slides in.

---

## 7. HOME PAGE (index.html)
Full `hero-gradient` + the two blurred orbs. Top→bottom:
1. Floating dock header.
2. Badge pill: **"Join the AI workflow"**.
3. Headline: **"A new level of freedom for your *business*"** (centered, white, "business" in `--primary`, `text-balance`).
4. Subheadline: **"Fonal AI change the way of doing business"** (centered, white ~85%).
5. **Stats bar** (`.glass-deep`, 3 columns split by white/20 hairlines, `rounded-3xl`):
   - **90%** — "of routine work automated"
   - **24/7** — "available"
   - **3X** — "faster the workflow"
   Numbers: Space Grotesk huge bold `--primary`; labels: uppercase x-small semibold white.
6. Whatever service/feature/CTA sections exist on the original index page — reproduce them (footer too).

---

## 8. LOGIN PAGE (login.html)
Full hero-gradient + orbs. One centered `.glass` card (`max-width 28rem`, `rounded-[2rem]`, padding 32–40px, `shadow-2xl`).
Top→bottom:
1. Kicker **"Welcome back"** (primary, uppercase).
2. Title **"Sign in"** (Space Grotesk 3xl bold).
3. Subtitle **"Access your Fonal AI dashboard"** (muted).
4. **Email field** — envelope icon left, `rounded-xl`, 1px border, focus ring in `--ring`, placeholder muted ("you@business.com").
5. **Password field** — lock icon left + eye/eye-off toggle right (shows/hides the value).
6. Row: **"Remember me"** checkbox (primary accent) + **"Forgot password?"** (primary link → "coming soon").
7. **"Sign in"** button — full-width, primary filled, `rounded-full`, brand shadow, arrow icon.
8. Divider `──  or continue with  ──`.
9. **Alternate options** (full-width outline pill, generic bg, `rounded-full`, gap ≈0.75rem between them):
   - **"Continue with mobile number"** (phone icon) → links to `login-mobile.html`.
   - **"Continue with Google"** (official 4-color Google logo).
   - **"Connect GitHub"** (black GitHub octocat logo).
10. Footer: **"Don't have an account? Create one"** (primary link → "coming soon").

**JS validation:** email must match `^[^\s@]+@[^\s@]+\.[^\s@]+$`, password ≥ 6 chars; show inline error on failure; on success redirect to `dashboard.html`.

---

## 9. MOBILE LOGIN (login-mobile.html)
Same bg + orbs + glass card. At the very top of the card: a **"← Back to sign in"** link → `login.html`.
- Kicker **"Welcome back"**, title **"Continue with mobile"**, subtitle **"Enter your mobile number to receive a one-time code"**.
- **Mobile number field** — phone icon left, `type=tel`, placeholder "+91 98765 43210".
- **"Send OTP"** button (primary, full width, arrow).
- After "Send OTP": an **OTP field** appears below — key icon left, `numeric` input ("6-digit code"), plus a note with shield icon "A verification code was sent to your mobile number."
- **"Verify & Continue"** button (primary, arrow) → on valid 4–6 digit OTP, redirect to `dashboard.html`.

---

## 10. DASHBOARD (dashboard.html) — app-like screen
Full-hero-gradient + orbs. The global floating header is HIDDEN here.

- **Sidebar (left):** fixed full-height column, `width 16rem`, uses **`.dock-blur`**, `border-right` white/40. Contains 5 nav items: **Orders, Menu, Chats, Analytics, Settings** — each = icon + label, `rounded-xl`, full-width; active = soft brand-tinted bg + brand icon/text, inactive = muted ink brightening on hover. Clicking switches the main content panel (tabs in JS). Mobile: sidebar off-canvas, toggled by hamburger, with a dim overlay.
- **Bottom-left dock:** a compact **`.dock-blur` rounded-full pill fixed to bottom-left**, aligned within the sidebar's width. Inside: hamburger + **"Fonal AI"** wordmark left; a **"Log in"** outline pill right.
- **Main content (right of sidebar):**
  - **Stats panel** (`.glass-deep`, `rounded-3xl`, 3 columns split by white/20): 90% / "of routine work automated", 24/7 / "available", 3X / "faster the workflow".
  - A **content panel** showing the current tab's title (e.g. "Orders") + a short placeholder description; swaps with the selected tab.

---

## 11. RESPONSIVE / BREAKPOINTS
- **Mobile (<md):** dock header collapses to hamburger + wordmark (+ drawer). Dashboard sidebar hidden off-canvas (toggle). Stats stack to 1 column (divide-y). Titles shrink to 5xl.
- **Tablet/desktop (md+):** full nav visible; dashboard sidebar always visible sticky full-height; stats 3-across (divide-x).
- Use fractional max-width containers and generous padding throughout.

---

## 12. FILE STRUCTURE TO DELIVER
```
fonal-ai-website/
  index.html          (home)
  about.html
  services.html
  connect.html
  login.html
  login-mobile.html
  dashboard.html
  css/styles.css      (all tokens, glass effects, animations, components)
  js/main.js          (nav drawer, dashboard tabs, login + OTP validation)
```
All pages share ONE `css/styles.css` and `js/main.js`. Internal links point to the matching `.html` files. Do NOT include the 3D canvas scene from the original home page — use the CSS orbs as its visual replacement so nothing blocks rendering.

---

## 13. FINAL CHECKLIST (must all pass)
- [ ] No frameworks, no build step, no external JS CDNs — pure HTML/CSS/JS.
- [ ] Exact oklch tokens (section 2) in `:root`.
- [ ] `.hero-gradient`, `.glass`, `.glass-deep`, `.dock-blur` exactly as section 4.
- [ ] Space Grotesk (display) + DM Sans (body) loaded via Google Fonts preconnect + stylesheet.
- [ ] Official Google 4-color logo, GitHub octocat, and inline SVG/lucide-style icons used (no icon font library).
- [ ] All animations: dock-in, scale-in, fade-in, button hover scale, hamburger micro-animation, sidebar active states.
- [ ] Floating top-center dock on all pages except dashboard; bottom-left dock only on dashboard.
- [ ] Login page options: mobile + Google + GitHub with small gaps between.
- [ ] login-mobile.html: number → Send OTP → OTP field → Verify → dashboard.
- [ ] Dashboard: dock-blur sidebar, 5 tabs switch content, bottom-left dock pinned.
- [ ] Fully responsive mobile / md / desktop.
- [ ] Opens by double-clicking index.html (works over file:// or any static host).
